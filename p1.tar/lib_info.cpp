//g++ -Wall -Wextra -std=c++11 -o lib_info lib_info.cpp
//Davis Greenwell
//Partner: Unknown
//Project 1

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <iomanip>
#include <algorithm>

//got these structs from the write up
struct Song {
    std::string title;
    int time;
};

struct Album {
    std::map<int, Song> songs;
    std::string name;
    int time = 0;
    int nsongs = 0;
};

struct Artist {
    std::map<std::string, Album> albums;
    std::string name;
    int time = 0;
    int nsongs = 0;
};

//convert minsec from input file to just seconds for ease of use in program
int parse_time(const std::string& time) 
{
    size_t colon_pos = time.find(':');
    if (colon_pos == std::string::npos) 
    {
        throw std::invalid_argument("Invalid time format: " + time);
    }

    int minutes = std::stoi(time.substr(0, colon_pos));
    int seconds = std::stoi(time.substr(colon_pos + 1));
    return minutes * 60 + seconds;
}

//takes in the seconds and outputs the minutes:seconds 
//with proper width for 1 minute 6 seconds to be 1:06 for example
//this is simply for output format because humans read minsec better than just sec
std::string format_time(int total_seconds) 
{
    int minutes = total_seconds / 60;
    int seconds = total_seconds % 60;
    std::ostringstream oss;
    oss << minutes << ":" << std::setw(2) << std::setfill('0') << seconds;
    return oss.str(); 
}

int main(int argc, char* argv[]) 
{
    if (argc != 2) 
    {
        std::cerr << "Usage: " << argv[0] << " file" << std::endl;
        return 1;
    }

    std::ifstream infile(argv[1]);
    if (!infile) 
    {
        std::cerr << "Error: Could not open file " << argv[1] << std::endl;
        return 1;
    }

    std::map<std::string, Artist> library;
    std::string line;

    //read input
    while (std::getline(infile, line)) 
    {
        std::istringstream iss(line);
        std::string title, time, artist, album, genre, track_str;

        if (!(iss >> title >> time >> artist >> album >> genre >> track_str)) 
        {
            std::cerr << "Error: Malformed input line: " << line << std::endl;
            continue;
        }

        //underscore goes to space
        std::replace(title.begin(), title.end(), '_', ' ');
        std::replace(artist.begin(), artist.end(), '_', ' ');
        std::replace(album.begin(), album.end(), '_', ' ');

        int track = std::stoi(track_str);
        int total_time = parse_time(time);

        //update lib
        Artist& artist_entry = library[artist];
        artist_entry.name = artist;
        artist_entry.time += total_time;
        artist_entry.nsongs++;

        Album& album_entry = artist_entry.albums[album];
        album_entry.name = album;
        album_entry.time += total_time;
        album_entry.nsongs++;

        Song song_entry = {title, total_time};
        album_entry.songs[track] = song_entry;
    }

    // Formatting and printing
    for (std::map<std::string, Artist>::const_iterator artist_it = library.begin(); artist_it != library.end(); ++artist_it) 
    {
        const Artist& artist = artist_it->second;
        std::cout << artist.name << ": " << artist.nsongs << ", " << format_time(artist.time) << std::endl;

        for (std::map<std::string, Album>::const_iterator album_it = artist.albums.begin(); album_it != artist.albums.end(); ++album_it) 
        {
            const Album& album = album_it->second;
            std::cout << "        " << album.name << ": " << album.nsongs << ", " << format_time(album.time) << std::endl;

            for (std::map<int, Song>::const_iterator song_it = album.songs.begin(); song_it != album.songs.end(); ++song_it) 
            {
                const Song& song = song_it->second;
                std::cout << "                " << song_it->first << ". " << song.title << ": " << format_time(song.time) << std::endl;
            }
        }
    }
    return 0;
}
